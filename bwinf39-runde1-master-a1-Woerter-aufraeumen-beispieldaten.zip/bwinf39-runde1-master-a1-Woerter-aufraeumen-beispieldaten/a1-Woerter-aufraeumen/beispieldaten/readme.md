Für jedes Rätsel enthält die entsprechende Datei

 * in der ersten den unvollständigen Text des Rätsels und
 * in der zweiten Zeile alle Wörter des Rätsels durch Leerzeichen getrennt.
